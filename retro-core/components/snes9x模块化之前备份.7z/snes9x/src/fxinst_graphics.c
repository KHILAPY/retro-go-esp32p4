/*****************************************************************************\
     Snes9x - Portable Super Nintendo Entertainment System (TM) emulator.
                This file is licensed under the Snes9x License.
   For further information, consult the LICENSE file in the root directory.
\*****************************************************************************/

#include "fxinst_internal.h"

void fx_color (void)
{
    COLR = SREG & 0xff;
    CLRFLAGS;
    R15++;
}

void fx_cmode (void)
{
    GSU.vPlotOptionReg = SREG & 0x1f;
    CLRFLAGS;
    R15++;
}

void fx_getc (void)
{
    DREG = COLR;
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    TESTR14;
    CLRFLAGS;
    R15++;
}

void fx_getb (void)
{
    DREG = GSU.vRomBuffer;
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void fx_getbh (void)
{
    DREG = (GSU.vRomBuffer >> 4) & 0x0f;
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void fx_getbl (void)
{
    DREG = GSU.vRomBuffer & 0x0f;
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void fx_getbs (void)
{
    DREG = SEX8(GSU.vRomBuffer);
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void fx_plot_2bit (void)
{
    uint32_t x = R1;
    uint32_t y = R2;

#ifdef CHECK_LIMITS
    if (y >= GSU.vScreenHeight)
        return;
#endif

    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 2);
    uint8_t pixel = COLR & 3;

    if (pixel)
        screen[offset >> 3] |= (pixel << ((offset & 7) << 1));
    else
        screen[offset >> 3] &= ~(3 << ((offset & 7) << 1));

    R1++;
    CLRFLAGS;
    R15++;
}

void fx_plot_4bit (void)
{
    uint32_t x = R1;
    uint32_t y = R2;

#ifdef CHECK_LIMITS
    if (y >= GSU.vScreenHeight)
        return;
#endif

    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 3);
    uint8_t pixel = COLR & 0x0f;

    if (pixel)
        screen[offset >> 1] |= (pixel << ((offset & 1) << 2));
    else
        screen[offset >> 1] &= ~(0x0f << ((offset & 1) << 2));

    R1++;
    CLRFLAGS;
    R15++;
}

void fx_plot_8bit (void)
{
    uint32_t x = R1;
    uint32_t y = R2;

#ifdef CHECK_LIMITS
    if (y >= GSU.vScreenHeight)
        return;
#endif

    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 4);

    screen[offset] = COLR;

    R1++;
    CLRFLAGS;
    R15++;
}

void fx_plot_obj (void)
{
    uint32_t x = R1;
    uint32_t y = R2;

    if (y >= 256)
        return;

    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 5);

    screen[offset] = COLR;

    R1++;
    CLRFLAGS;
    R15++;
}

void fx_rpix_2bit (void)
{
    uint32_t x = R1;
    uint32_t y = R2;
    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 2);

    DREG = (screen[offset >> 3] >> ((offset & 7) << 1)) & 3;
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void fx_rpix_4bit (void)
{
    uint32_t x = R1;
    uint32_t y = R2;
    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 3);

    DREG = (screen[offset >> 1] >> ((offset & 1) << 2)) & 0x0f;
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void fx_rpix_8bit (void)
{
    uint32_t x = R1;
    uint32_t y = R2;
    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 4);

    DREG = screen[offset];
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void fx_rpix_obj (void)
{
    uint32_t x = R1;
    uint32_t y = R2;
    uint8_t *screen = GSU.apvScreen[x >> 3];
    uint32_t offset = GSU.x[x >> 3] + (y & 0x7) + ((y & ~0x7) << 5);

    DREG = screen[offset];
    GSU.vSign = DREG;
    GSU.vZero = DREG;
    CLRFLAGS;
    R15++;
}

void (*fx_PlotTable[]) (void) =
{
    &fx_plot_2bit, &fx_plot_4bit, &fx_plot_4bit, &fx_plot_8bit, &fx_plot_obj,
    &fx_rpix_2bit, &fx_rpix_4bit, &fx_rpix_4bit, &fx_rpix_8bit, &fx_rpix_obj
};
