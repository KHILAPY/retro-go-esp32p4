#pragma once

#include <stdbool.h>
#include <stdint.h>

bool S9xSaveState(const char *filename);
bool S9xLoadState(const char *filename);
