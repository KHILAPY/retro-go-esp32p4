# Snes9x port for Retro-Go

## Based on:

I believe it was based on https://github.com/libretro/snes9x2010

## Modifications:

